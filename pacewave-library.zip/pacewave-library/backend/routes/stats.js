// =====================================================================
// Statistics routes (admin dashboard)
// ---------------------------------------------------------------------
// Private: GET /api/admin/stats
// =====================================================================
const express = require('express');
const router = express.Router();
const statsController = require('../controllers/stats');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

router.get('/', requireAuth, asyncHandler(statsController.getStats));

module.exports = router;
