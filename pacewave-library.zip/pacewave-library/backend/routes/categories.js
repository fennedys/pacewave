// =====================================================================
// Categories routes
// ---------------------------------------------------------------------
// Public:  list, get
// Private: create, update, delete
// =====================================================================
const express = require('express');
const router = express.Router();
const categoriesController = require('../controllers/categories');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

// Public
router.get('/', asyncHandler(categoriesController.listCategories));
router.get('/:id', asyncHandler(categoriesController.getCategory));

// Protected
router.post('/', requireAuth, asyncHandler(categoriesController.createCategory));
router.put('/:id', requireAuth, asyncHandler(categoriesController.updateCategory));
router.delete('/:id', requireAuth, asyncHandler(categoriesController.deleteCategory));

module.exports = router;
