// =====================================================================
// Chapters controller
// ---------------------------------------------------------------------
// Chapters are stored as plain text in the `chapters` table (not PDFs).
// Each book can have unlimited chapters, ordered by chapter_no.
// =====================================================================
const { supabaseAdmin } = require('../config/supabase');
const { asyncHandler } = require('../middleware/error');

// GET /api/books/:bookId/chapters  - list all chapters of a book
const listChapters = asyncHandler(async (req, res) => {
  const { bookId } = req.params;
  const { data, error } = await supabaseAdmin
    .from('chapters')
    .select('*')
    .eq('book_id', bookId)
    .order('chapter_no');

  if (error) return res.status(500).json({ error: error.message });
  res.json({ chapters: data });
});

// GET /api/chapters/:id  - single chapter
const getChapter = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { data, error } = await supabaseAdmin
    .from('chapters')
    .select('*, book:books(id, title, author)')
    .eq('id', id)
    .single();

  if (error || !data) return res.status(404).json({ error: 'Chapter not found.' });
  res.json({ chapter: data });
});

// GET /api/books/:bookId/chapters/:chapterNo - get by number (reader uses this)
const getChapterByNumber = asyncHandler(async (req, res) => {
  const { bookId, chapterNo } = req.params;
  const { data, error } = await supabaseAdmin
    .from('chapters')
    .select('*')
    .eq('book_id', bookId)
    .eq('chapter_no', Number(chapterNo))
    .single();

  if (error || !data) {
    return res.status(404).json({ error: 'Chapter not found.' });
  }

  // Include total chapter count + neighbor titles for nav.
  const { data: bookChapters } = await supabaseAdmin
    .from('chapters')
    .select('id, chapter_no, title')
    .eq('book_id', bookId)
    .order('chapter_no');

  const list = bookChapters || [];
  const idx = list.findIndex((c) => c.chapter_no === Number(chapterNo));

  res.json({
    chapter: data,
    total_chapters: list.length,
    prev: idx > 0 ? list[idx - 1] : null,
    next: idx >= 0 && idx < list.length - 1 ? list[idx + 1] : null,
  });
});

// POST /api/books/:bookId/chapters - add a chapter to a book
const createChapter = asyncHandler(async (req, res) => {
  const { bookId } = req.params;
  const { title, content = '', chapter_no } = req.body;

  if (!title || title.trim() === '') {
    return res.status(400).json({ error: 'Chapter title is required.' });
  }
  if (content.trim() === '') {
    return res.status(400).json({ error: 'Chapter content cannot be empty.' });
  }

  // If no chapter number provided, append after the last one.
  let number = chapter_no;
  if (!number) {
    const { data: last } = await supabaseAdmin
      .from('chapters')
      .select('chapter_no')
      .eq('book_id', bookId)
      .order('chapter_no', { ascending: false })
      .limit(1)
      .maybeSingle();
    number = (last?.chapter_no || 0) + 1;
  }

  const { data, error } = await supabaseAdmin
    .from('chapters')
    .insert({ book_id: bookId, title, content, chapter_no: Number(number) })
    .select()
    .single();

  if (error) {
    return res.status(500).json({ error: error.message });
  }
  res.status(201).json({ chapter: data });
});

// PUT /api/chapters/:id - update a chapter
const updateChapter = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { title, content, chapter_no } = req.body;

  const patch = {};
  if (title !== undefined) {
    if (title.trim() === '') return res.status(400).json({ error: 'Title is required.' });
    patch.title = title;
  }
  if (content !== undefined) patch.content = content;
  if (chapter_no !== undefined) patch.chapter_no = Number(chapter_no);

  const { data, error } = await supabaseAdmin
    .from('chapters').update(patch).eq('id', id).select().single();
  if (error || !data) return res.status(404).json({ error: 'Chapter not found.' });

  res.json({ chapter: data });
});

// DELETE /api/chapters/:id - delete a chapter
const deleteChapter = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { error } = await supabaseAdmin.from('chapters').delete().eq('id', id);
  if (error) return res.status(500).json({ error: error.message });
  res.json({ message: 'Chapter deleted.', id });
});

module.exports = {
  listChapters,
  getChapter,
  getChapterByNumber,
  createChapter,
  updateChapter,
  deleteChapter,
};
