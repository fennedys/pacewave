// =====================================================================
// PaceWave Library - Express server
// ---------------------------------------------------------------------
// Entry point. Wires up middleware, mounts the REST API routes, serves
// the built frontend and starts listening.
// =====================================================================
require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

// Middleware + routes
const { notFound, errorHandler } = require('./middleware/error');

const app = express();
const PORT = process.env.PORT || 4000;

// ---- Security headers (helmet) ----
app.use(
  helmet({
    contentSecurityPolicy: false, // allow inline styles used by the frontend
  })
);

// ---- CORS: allow the frontend origin(s) ----
const allowedOrigins = (process.env.CORS_ORIGIN || '*').split(',').map((s) => s.trim());
app.use(
  cors({
    origin: (origin, cb) => {
      // No origin (curl, same-origin) or allowed origin -> accept.
      if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
        return cb(null, true);
      }
      return cb(new Error('Not allowed by CORS'));
    },
    credentials: true,
  })
);

// ---- Body parsing ----
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ---- Rate limiting: slow down brute-force login attempts ----
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { error: 'Too many requests. Please try again later.' },
});

// ---- Static frontend (deployment: backend serves the built site) ----
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.use(express.static(path.join(__dirname, '..', 'admin')));

// ---- API routes ----
app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'PaceWave Library API' }));

app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/books', require('./routes/books'));
app.use('/api/chapters', require('./routes/chapters'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/featured', require('./routes/featured'));
app.use('/api/progress', require('./routes/progress'));
app.use('/api/admin/stats', require('./routes/stats'));

// ---- 404 + error handler ----
app.use(notFound);
app.use(errorHandler);

// ---- Start ----
app.listen(PORT, '0.0.0.0', () => {
  const { configured } = require('./config/supabase');
  console.log(`\n  PaceWave Library API running`);
  console.log(`  ➜ API:    http://localhost:${PORT}/api`);
  console.log(`  ➜ Site:   http://localhost:${PORT}/`);
  console.log(`  ➜ Admin:  http://localhost:${PORT}/login.html`);
  console.log(`  ➜ Supabase: ${configured ? 'CONFIGURED ✓' : 'NOT CONFIGURED (see .env)'}\n`);
});
