# PaceWave Library — Setup & Deployment Guide

## 1. Project structure

```
pacewave-library/
├── frontend/                  # Public website (HTML/CSS/Vanilla JS)
│   ├── index.html             # Homepage
│   ├── library.html           # Browse all books
│   ├── reader.html            # Reading page (chapter by chapter)
│   ├── style.css              # Shared styles (glassmorphism, purple/blue)
│   └── app.js                 # Shared frontend logic + config
├── admin/                     # Admin dashboard
│   ├── login.html             # Admin login
│   ├── dashboard.html         # Dashboard with stats + CRUD
│   ├── admin.css
│   └── admin.js
├── backend/                   # Node.js + Express API
│   ├── server.js              # Entry point
│   ├── routes/                # REST route definitions
│   ├── controllers/           # Business logic
│   ├── middleware/            # Auth, validation, error handling
│   ├── config/                # Supabase + upload config
│   └── .env.example           # Copy to .env
├── database/
│   └── schema.sql             # Supabase PostgreSQL schema + RLS + seed
└── docs/
    ├── API.md                 # API reference
    └── SETUP.md               # This file
```

---

## 2. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project**.
2. Note your **Project URL** and keys under **Project Settings → API**:
   - `SUPABASE_URL` (e.g. `https://abc.supabase.co`)
   - `SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (secret — backend only)
   - `SUPABASE_JWT_SECRET`

3. Run the database schema:
   - Open **SQL Editor → New query**.
   - Paste the contents of `database/schema.sql` and click **Run**.
   - This creates all tables, indexes, triggers, RLS policies and seed categories.

4. Create your admin user:
   - **Authentication → Users → Add user**, enter an email + password.
   - Grab the new user's **UUID**.
   - Run this SQL (SQL Editor):
     ```sql
     INSERT INTO admins (id, email, name) VALUES
     ('<THE_USER_UUID>', 'you@example.com', 'Your Name');
     ```
   - The backend also auto-creates the admin row on first login, so this step is optional.

5. Optional — create the storage bucket:
   - **Storage → New bucket → name `covers` → Public**.
   - The backend creates it automatically if missing.

---

## 3. Configure the backend

```bash
cd backend
cp .env.example .env
```

Edit `backend/.env` and fill in the Supabase values (see step 2).

---

## 4. Install & run locally

```bash
cd backend
npm install
npm run dev        # starts API on http://localhost:4000
```

The backend serves the frontend and admin too:
- Public site → `http://localhost:4000/`
- Admin login → `http://localhost:4000/login.html`

Or run the frontend as a static site however you like.

---

## 5. Using the admin dashboard

1. Open `http://localhost:4000/login.html`.
2. Log in with the Supabase Auth email/password from step 2.
3. On the dashboard you can:
   - Add/edit/delete books (title, author, category, description, cover upload).
   - Add unlimited chapters with the dynamic chapter editor.
   - Mark books **Featured** and **New Arrival**.
   - Manage categories.
   - Manage homepage featured order.
   - View stats + recent books.
   - Search books.

---

## 6. Deployment (Render / Railway / Fly.io / Vercel)

The backend serves everything, so deploy it as a single Node service:

1. Push the repo to GitHub.
2. On Render/Railway create a **Web Service** pointing at the repo.
   - Build command: `npm install --prefix backend`
   - Start command: `node backend/server.js`
3. Set all environment variables from `.env` in the host's dashboard.
4. Deploy. The site + admin + API all live behind one URL.

For Vercel you'd split it into a Serverless API and static frontend; the included structure keeps the backend as the origin to keep it simple.

---

## 7. Security notes

- The **service role key** is only used by the backend and never exposed.
- Admin routes are protected by `requireAuth` (Supabase JWT verification).
- Row Level Security blocks public writes to all library tables.
- Login is rate-limited to slow brute-force attempts.
- Uploads are validated by type and size (5 MB cap).
- Central error handling hides internal errors from clients.

---

## 8. Expanding later

- Add a public reader account system by enabling Supabase Auth for readers and giving `reading_progress` a FK to `auth.users`.
- Add search by tags or full-text search with PostgreSQL `tsvector`.
- Add per-chapter ratings and comments.
- Serve covers via Supabase's CDN URLs (already the case).
